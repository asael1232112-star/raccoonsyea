package com.raccoon.menu;

import java.lang.reflect.Method;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

/**
 * 26.1 uses Minecraft#setScreen, 26.2+ renamed it to setScreenAndShow.
 * Reflection (names are unobfuscated) lets one jar work on both.
 */
public final class ScreenCompat {
    private static Method setter;

    private ScreenCompat() {}

    public static void show(Screen screen) {
        Minecraft mc = Minecraft.getInstance();
        try {
            if (setter == null) {
                try {
                    setter = Minecraft.class.getMethod("setScreenAndShow", Screen.class);
                } catch (NoSuchMethodException e) {
                    setter = Minecraft.class.getMethod("setScreen", Screen.class);
                }
            }
            setter.invoke(mc, screen);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException("Raccoon Menu: could not change screen on this Minecraft version", e);
        }
    }
}

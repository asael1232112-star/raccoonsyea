package com.raccoon.menu;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class RaccoonMenuScreen extends Screen {
    // ---- layout ----
    private static final int PANEL_W = 320, PANEL_H = 190, HEADER_H = 34;
    private static final int COLS = 3, BTN_W = 92, BTN_H = 30, GAP = 6;
    private static final String[] LABELS = {
            "Auction House", "Bazaar", "Warps",
            "Kits", "Shop", "Stats",
            "Friends", "Settings", "Close"
    };
    private static final int CLOSE_INDEX = LABELS.length - 1;

    // ---- raccoon palette (RGB) ----
    private static final int OUTLINE = 0x15161A;   // mask black
    private static final int FUR_DARK = 0x2A2B2F;
    private static final int FUR_BASE = 0x4B4E54;  // base raccoon gray
    private static final int FUR_MID = 0x6E7177;
    private static final int FUR_LIGHT = 0xB4B7BD;
    private static final int BTN_IDLE = 0x3A3C41;
    private static final int BTN_HOVER = 0x7A7D84;

    private static final long OPEN_MS = 380, CLOSE_MS = 180;

    private final float[] hover = new float[LABELS.length];
    private final float[] flash = new float[LABELS.length];
    private final long openStart = System.currentTimeMillis();
    private long closeStart = -1;
    private boolean finished = false;
    private String status = "Test build - click a button";

    // pivot of the last drawn frame, used to map mouse coords into panel space
    private float scale = 1f, pivotX, pivotY, centerY;

    public RaccoonMenuScreen() {
        super(Component.literal("Raccoon Menu"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ---------------------------------------------------------------- input

    @Override
    public void onClose() {
        if (closeStart < 0) closeStart = System.currentTimeMillis();
    }

    @Override
    public void tick() {
        if (closeStart >= 0 && !finished && System.currentTimeMillis() - closeStart >= CLOSE_MS) {
            finished = true;
            ScreenCompat.show(null);
        }
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (RaccoonMenuClient.OPEN_KEY != null && RaccoonMenuClient.OPEN_KEY.matches(event)) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (closeStart < 0 && event.button() == 0) {
            float lx = (float) ((event.x() - width / 2f) / scale + width / 2f);
            float ly = (float) ((event.y() - pivotY) / scale + centerY);
            for (int i = 0; i < LABELS.length; i++) {
                if (inside(lx, ly, btnX(i), btnY(i), BTN_W, BTN_H)) {
                    flash[i] = 1f;
                    if (i == CLOSE_INDEX) {
                        onClose();
                    } else {
                        status = "Clicked: " + LABELS[i] + " (not implemented yet)";
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    // ------------------------------------------------------------- rendering

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        long now = System.currentTimeMillis();
        boolean closing = closeStart >= 0;

        float p = closing
                ? 1f - clamp((now - closeStart) / (float) CLOSE_MS)
                : clamp((now - openStart) / (float) OPEN_MS);
        float e = closing ? p : easeOutBack(p);
        float alpha = Math.min(1f, p * 1.6f);

        scale = 0.86f + 0.14f * e;
        centerY = height / 2f;
        pivotY = centerY + (1f - e) * 16f; // slides up into place
        float cx = width / 2f;

        // dim backdrop
        g.fill(0, 0, width, height, argb(alpha * 0.55f, 0x000000));

        float lx = (mouseX - cx) / scale + cx;
        float ly = (mouseY - pivotY) / scale + centerY;

        g.pose().pushMatrix();
        g.pose().translate(cx, pivotY);
        g.pose().scale(scale, scale);
        g.pose().translate(-cx, -centerY);

        int x = panelX(), y = panelY();

        // soft shadow
        rrect(g, x - 3, y - 1, x + PANEL_W + 3, y + PANEL_H + 5, argb(alpha * 0.25f, 0x000000));

        // ears
        rrect(g, x + 18, y - 8, x + 42, y + 6, argb(alpha, OUTLINE));
        rrect(g, x + 22, y - 5, x + 38, y + 6, argb(alpha, FUR_MID));
        rrect(g, x + PANEL_W - 42, y - 8, x + PANEL_W - 18, y + 6, argb(alpha, OUTLINE));
        rrect(g, x + PANEL_W - 38, y - 5, x + PANEL_W - 22, y + 6, argb(alpha, FUR_MID));

        // body + border
        rrect(g, x - 1, y - 1, x + PANEL_W + 1, y + PANEL_H + 1, argb(alpha, OUTLINE));
        rrect(g, x, y, x + PANEL_W, y + PANEL_H, argb(alpha, FUR_BASE));

        // header ("mask")
        rrect(g, x, y, x + PANEL_W, y + HEADER_H, argb(alpha, FUR_DARK));
        g.fill(x, y + HEADER_H - 4, x + PANEL_W, y + HEADER_H, argb(alpha, FUR_DARK));
        g.fill(x, y + HEADER_H, x + PANEL_W, y + HEADER_H + 1, argb(alpha, FUR_MID));
        text(g, "RACCOON MENU", x + 16, y + 13, 0xF2F2F4, alpha);
        String tag = "test build";
        text(g, tag, x + PANEL_W - 16 - font.width(tag), y + 13, FUR_LIGHT, alpha * 0.8f);

        // buttons (staggered fade/slide in)
        long elapsed = now - openStart;
        for (int i = 0; i < LABELS.length; i++) {
            float t = closing ? 1f : clamp((elapsed - 120 - i * 45L) / 260f);
            float te = easeOutCubic(t);
            int off = Math.round((1f - te) * 10f);
            float ba = alpha * te;

            int bx = btnX(i), by = btnY(i) + off;
            boolean over = !closing && te > 0.9f && inside(lx, ly, bx, btnY(i), BTN_W, BTN_H);
            hover[i] += ((over ? 1f : 0f) - hover[i]) * 0.25f;
            flash[i] *= 0.88f;
            float h = hover[i];

            rrect(g, bx, by, bx + BTN_W, by + BTN_H, argb(ba, lerpColor(BTN_IDLE, BTN_HOVER, h)));

            int accent = i == CLOSE_INDEX ? 0xC26B5E : 0xE4E5E8;
            g.fill(bx + 1, by + 5, bx + 3 + Math.round(h * 2), by + BTN_H - 5,
                    argb(ba * (0.35f + 0.65f * h), accent));

            String label = LABELS[i];
            text(g, label, bx + (BTN_W - font.width(label)) / 2, by + (BTN_H - 8) / 2 + 1,
                    lerpColor(0xC9CBD0, 0xFFFFFF, h), ba);

            if (flash[i] > 0.02f) {
                rrect(g, bx, by, bx + BTN_W, by + BTN_H, argb(ba * flash[i] * 0.4f, 0xFFFFFF));
            }
        }

        // status bar
        int sy = btnY(LABELS.length - 1) + BTN_H + 10;
        rrect(g, x + 16, sy, x + PANEL_W - 16, sy + 16, argb(alpha, 0x2E3035));
        text(g, font.plainSubstrByWidth(status, PANEL_W - 44), x + 22, sy + 4, FUR_LIGHT, alpha);

        // ringed tail stripes along the bottom
        for (int sx = 6, k = 0; sx + 14 <= PANEL_W - 6; sx += 14, k++) {
            g.fill(x + sx, y + PANEL_H - 6, x + sx + 14, y + PANEL_H - 2,
                    argb(alpha, k % 2 == 0 ? FUR_DARK : FUR_MID));
        }

        g.pose().popMatrix();
    }

    // --------------------------------------------------------------- helpers

    private int panelX() { return width / 2 - PANEL_W / 2; }
    private int panelY() { return height / 2 - PANEL_H / 2; }
    private int btnX(int i) { return panelX() + 16 + (i % COLS) * (BTN_W + GAP); }
    private int btnY(int i) { return panelY() + HEADER_H + 14 + (i / COLS) * (BTN_H + GAP); }

    private static boolean inside(float mx, float my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void text(GuiGraphicsExtractor g, String s, int x, int y, int rgb, float a) {
        if (a * 255f < 8f) return; // vanilla treats near-zero alpha text as opaque
        g.text(font, s, x, y, argb(a, rgb), true);
    }

    /** Rounded rect built from non-overlapping fills so translucency stays even. */
    private static void rrect(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int c) {
        g.fill(x1 + 2, y1, x2 - 2, y2, c);
        g.fill(x1 + 1, y1 + 1, x1 + 2, y2 - 1, c);
        g.fill(x2 - 2, y1 + 1, x2 - 1, y2 - 1, c);
        g.fill(x1, y1 + 2, x1 + 1, y2 - 2, c);
        g.fill(x2 - 1, y1 + 2, x2, y2 - 2, c);
    }

    private static int argb(float a, int rgb) {
        int al = Math.max(0, Math.min(255, Math.round(a * 255f)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    private static int lerpColor(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }

    private static float easeOutCubic(float t) { return 1f - (float) Math.pow(1f - t, 3); }

    private static float easeOutBack(float t) {
        float c1 = 1.70158f, c3 = c1 + 1f;
        float u = t - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }
}
